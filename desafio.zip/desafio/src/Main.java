import java.util.Scanner;
class Conversor {
   static Scanner scanner = new Scanner(System.in);

    static double CF (double C){ //celsius -> fahrenheit
        double F = (C * 9/5) + 32;
        return F;
    }
    static double CK (double C){ //celsius -> kelvin
        double K = C + 273.15;
        return K;
    }
    static double FC (double F){ //fahrenheit -> celsius
        double C = (F - 32) * 5/9;
        return C;
    }
    static double FK (double F){ //fahrenheit -> kelvin
        double K = (F - 32) * 5/9 + 273.15;
        return K;
    }
    static double KF (double K){ //kelvin -> fahrenheit
        double F = (K - 273.15) * 9/5 + 32;
        return F;
    }
    static double KC (double K){ //kelvin -> celsius
        double C = K - 273.15;
        return C;
    }
    static double input(String escala){
        System.out.println("Insira o valor em "+escala+":");
        double valor = scanner.nextDouble();
        return valor;
    }
    static void output(double valor, String escala){
        System.out.println("Valor em " + escala + ": " + valor);
    }

    public static void main(String[] args) {
        System.out.println("1. Celsius para Fahrenheit\n2. Celsius para Kelvin\n"+
                "3. Fahrenheit para Celsius\n4. Fahrenheit para Kelvin\n"+
                "5. Kelvin para Celsius\n6. Kelvin para Fahrenheit\n7. Sair");
        do {
            System.out.println("\nEscolha a transferencia: ");
            int multE = scanner.nextInt();
            double opc = 0;
            switch (multE){
                case 1: opc = input("Celsius");
                    output(CF(opc), "Fahrenheit");
                    break;
                case 2: opc = input("Celsius");
                    output(CK(opc),"Kelvin");
                    break;
                case 3: opc = input("Fahrenheit");
                    output(FC(opc), "Celsius");
                    break;
                case 4: opc = input("Fahrenheit");
                    output(FK(opc),"Kelvin");
                    break;
                case 5: opc = input("Kelvin");
                    output(KC(opc),"Celsius");
                    break;
                case 6: opc = input("Kelvin");
                    output(KF(opc), "Fahrenheit");
                    break;
                case 7:
                    System.out.println("Finish!");
                    System.exit(0);
                    break;
                default: System.out.println("Alternativa Invalida");
            }
        }while(true);
    }
}